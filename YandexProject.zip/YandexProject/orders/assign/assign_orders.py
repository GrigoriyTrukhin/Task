weight = {'foot': 10,
          'bike': 15,
          'car': 50
          }

courier_id = 2

#вернуть время назначенного заказа