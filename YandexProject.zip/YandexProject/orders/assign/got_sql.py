import sqlite3
way = 'C:/Users/Григорий/PycharmProjects/YandexProject/couriesrs/couriers.db'
db = sqlite3.connect(way)
cur = db.cursor()

id = 2

sql = f"""
SELECT DISTINCT *
FROM couriers
WHERE courier_id = {id}
"""

# ограниечени по: времени, весу
cur.execute(sql)
print(*cur.fetchall(), sep='\n')